#include "opencv2/opencv.hpp"  
#include "ViBe.h"  
#include <iostream>  
#include <cstdio>  
#include "MorphoFeatures.h"

using namespace cv;
using namespace std;

int main(int argc, char* argv[])
{
	Mat frame, gray, mask, corners;
	static Mat lastFrame;
	VideoCapture capture;
	MorphoFeatures morpho;
	int i = 0;
	capture.open("..//vedio//test.avi");

	if (!capture.isOpened())
	{
		cout << "No camera or video input!\n" << endl;
		return -1;
	}

	ViBe_BGS Vibe_Bgs;
	int count = 0;

	while (1)
	{
		i++;
		count++;
		capture >> frame;
		if (frame.empty())
			break;
		cvtColor(frame, gray, CV_RGB2GRAY);
		//imshow("input", frame);
		if (count == 1)
		{
			Vibe_Bgs.init(gray);
			Vibe_Bgs.processFirstFrame(gray);
			cout << " Training GMM complete!" << endl;
		}
		else
		{
			Vibe_Bgs.testAndUpdate(gray);
			mask = Vibe_Bgs.getMask();
			morphologyEx(mask, mask, MORPH_OPEN, Mat());
			if (i==2)
			{
				lastFrame = frame;
				imwrite("..//image//Gray_Image.jpg", lastFrame);
				cout << "�Ѵ�" << endl;
			}
			if (i == 30)
			{
				//imshow("lastFrame", lastFrame);
				//imshow("frame", frame);
				//capture.set(CV_CAP_PROP_POS_FRAMES, count - 99) >> lastFrame;
				lastFrame = imread("..//image//Gray_Image.jpg");
				//imshow("lastFrame", lastFrame);
				//imshow("frame", frame);
				morpho.cornersTest(lastFrame, frame);
				i = 0;
			}
			cout << i << endl;
			
			
			/*corners = morpho.getCorners(mask);
			morpho.drawOnImage(corners, frame);
			imshow("output", frame);*/
		}

		//imshow("input", frame);

		waitKey(100);
	}

	return 0;
}